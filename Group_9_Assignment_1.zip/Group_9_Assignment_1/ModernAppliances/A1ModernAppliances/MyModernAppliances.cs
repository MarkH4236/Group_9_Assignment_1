﻿using ModernAppliances.Entities;
using ModernAppliances.Entities.Abstract;
using ModernAppliances.Helpers;

/// Write by
/// Sirisak(Mark) Horkriengkrai and Natthawat Seingchin
/// Version 11/02/2024

namespace ModernAppliances
{
    /// <summary>
    /// Manager class for Modern Appliances
    /// </summary>
    /// <remarks>Author: </remarks>
    /// <remarks>Date: </remarks>

    internal class MyModernAppliances : ModernAppliances
    {
        /// <summary>
        /// Option 1: Performs a checkout
        /// </summary>

        // Checkout() function
        // This function will get input from users which is itemNumber
        // and get itemNumber then go to foreach loop to check which item matches with given itemNumber
        // then assign itemNumber to foundAppliance after that if-else statement are created
        // to filter the result if foundAppliance is null return not found
        // else if appliances are found and that appliances are available checkout() from appliance will be called.

        public override void Checkout()
        {
            // Write "Enter the item number of an appliance: "
            Console.WriteLine("Enter the item number of an appliance: ");

            // Create long variable to hold item number
            long? itemNumber = null;

            // Get user input as string and assign to variable.
            // Convert user input from string to long and store as item number variable.
            string? user_input = Console.ReadLine();

            if (user_input != null)
            {
                itemNumber = long.Parse(user_input);
            }
            else
            {
                Checkout();
            }

            // Create 'foundAppliance' variable to hold appliance with item number
            // Assign null to foundAppliance (foundAppliance may need to be set as nullable)
            long? foundAppliance = null;

            // Loop through Appliances
            // Test appliance item number equals entered item number
            foreach (Appliance appliance in Appliances)
            {
                if (appliance.ItemNumber == itemNumber)
                {
                    // Assign appliance in list to foundAppliance variable
                    // Break out of loop (since we found what need to)
                    foundAppliance = itemNumber;
                    break;
                }
            }

            // Test appliance was not found (foundAppliance is null)
            // Write "No appliances found with that item number."
            if (foundAppliance == null)
            {
                Console.WriteLine("No appliances found with that item number.\n");
            }

            // Otherwise (appliance was found)
            else
            {
                foreach (Appliance appliance in Appliances)
                {
                    // Test found appliance is available
                    // Checkout found appliance
                    // Write "Appliance has been checked out."
                    if (appliance.ItemNumber == foundAppliance && appliance.IsAvailable == true)
                    {
                        appliance.Checkout();
                        Console.WriteLine("Appliance \"{0}\" has been checked out.\n", foundAppliance);
                        break;
                    }
                    // Otherwise (appliance isn't available)
                    // Write "The appliance is not available to be checked out."
                    else if (appliance.ItemNumber == foundAppliance && appliance.IsAvailable == false)
                    {
                        Console.WriteLine("Appliance \"{0}\" is not available to be checked out.\n", foundAppliance);
                        break;
                    }
                }
            }
        }

        /// <summary>
        /// Option 2: Finds appliances
        /// </summary>

        // Find() function
        // This function prompts the user to enter a brand to search for.
        // It then iterates through the list of appliances and adds any matching appliances to a list.
        // Finally, it displays the found appliances.

        public override void Find()
        {
            // Write "Enter brand to search for:"

            Console.WriteLine("Enter brand to search for: ");

            // Create string variable to hold entered brand
            // Get user input as string and assign to variable.

            string inputBrand = Console.ReadLine();


            // Create list to hold found Appliance objects
            List<Appliance> foundApp = new List<Appliance>();

            // Iterate through loaded appliances
            foreach (var appliance in Appliances)
            {
                // Test current appliance brand matches what user entered
                if (appliance.Brand == inputBrand)
                {
                    // Add current appliance to found list
                    foundApp.Add(appliance);
                }
            }

            // Display found appliances
            // DisplayAppliancesFromList(found, 0);
            DisplayAppliancesFromList(foundApp, 0);
        }

        /// <summary>
        /// Displays Refridgerators
        /// </summary>
      
        // DisplayRefrigerators () function
        // It begins by displaying the options for the number of doors (any, double, triple, or quadruple)
        // prompting the user to make a selection.
        // After receiving the user's input, it filters through a collection of appliances
        // identifying those that are refrigerators and matching the specified number of doors.
        // It then displays the list of found refrigerators to the user.

        public override void DisplayRefrigerators()
        {
            // Write "Possible options:"
            // Write "0 - Any"
            // Write "2 - Double doors"
            // Write "3 - Three doors"
            // Write "4 - Four doors"
            Console.WriteLine("Possible options:\n" +
                "0 - Any" + "\n" +
                "2 - Double doors" + "\n" +
                "3 - Three doors" + "\n" +
                "4 - Four doors" + "\n");

            // Write "Enter number of doors: "
            Console.WriteLine("Enter number of doors: 2 (double door), 3 (three doors) or 4 (four doors):");

            // Create variable to hold entered number of doors
            int? numberOfDoors = null;
            // Get user input as string and assign to variable
            string? user_input = Console.ReadLine();

            // Convert user input from string to int and store as number of doors variable.
            if (user_input != null)
            {
                numberOfDoors = int.Parse(user_input);
            }
            else
            {
                DisplayRefrigerators();
            }

            // Create list to hold found Appliance objects
            List<Appliance> found = new List<Appliance>();

            // Iterate/loop through Appliances
            // Test that current appliance is a refrigerator
            foreach (Appliance appliance in Appliances)

            {
                // Down cast Appliance to Refrigerator
                // Refrigerator refrigerator = (Refrigerator) appliance;
                if (Appliance.DetermineApplianceTypeFromItemNumber(appliance.ItemNumber) == Appliance.ApplianceTypes.Refrigerator)
                {
                    // Test user entered 0 or refrigerator doors equals what user entered.
                    // Add current appliance in list to found list
                    Refrigerator refrigerator = (Refrigerator)appliance;
                    if (numberOfDoors == refrigerator.Doors)
                    {
                        found.Add(refrigerator);
                    }
                }
            }

            // Display found appliances
            DisplayAppliancesFromList(found, 0);
        }

        /// <summary>
        /// Displays Vacuums
        /// </summary>
        /// <param name="grade">Grade of vacuum to find (or null for any grade)</param>
        /// <param name="voltage">Vacuum voltage (or 0 for any voltage)</param>
       
        // DisplayVacuumes () function
        // It begins by displaying the available options for both grade and voltage. 
        // After receiving the user's input for grade and voltage,
        // it filters through a collection of appliances to identify vacuum cleaners matching the specified criteria.
        // Once the relevant vacuum cleaners are found, it displays them to the user. 

        public override void DisplayVacuums()
        {
            // Write "Possible options:"
            // Write "0 - Any"
            // Write "1 - Residential"
            // Write "2 - Commercial"
            Console.WriteLine("Possible options:\n" +
                "0 - Any" + "\n" +
                "1 - Residential" + "\n" +
                "2 - Commercial" + "\n");

            // Write "Enter grade:"
            Console.WriteLine("Enter grade:");
            // Get user input as string and assign to variable
            string? user_grade_options = Console.ReadLine();
            // Create grade variable to hold grade to find (Any, Residential, or Commercial)
            string? grade = null;

            // Test input is "0"
            if (user_grade_options == "0")
            {
                // Assign "Any" to grade
                grade = "Any";
            }
            // Test input is "1"
            else if (user_grade_options == "1")
            {
                // Assign "Residential" to grade
                grade = "Residential";
            }
            // Test input is "2"
            else if (user_grade_options == "2")
            {
                // Assign "Commercial" to grade
                grade = "Commercial";
            }
            // Otherwise (input is something else)
            else
            {
                // Write "Invalid option."
                Console.WriteLine("Invalid option.\n");
                // Return to calling (previous) method
                DisplayVacuums();
                return;
            }

            // Write "Possible options:"
            // Write "0 - Any"
            // Write "1 - 18 Volt"
            // Write "2 - 24 Volt"
            Console.WriteLine("Possible options:\n" +
                "0 - Any" + "\n" +
                "1 - 18 Volt" + "\n" +
                "2 - 24 Volt" + "\n");

            // Write "Enter voltage:"
            Console.WriteLine("\nEnter voltage:");
            // Get user input as string
            string? user_volt_options = Console.ReadLine();
            // Create variable to hold voltage
            short? voltage = null;

            // Test input is "0"
            if (user_volt_options == "0")
            {
                // Assign 0 to voltage
                voltage = 0;
            }
            // Test input is "1"
            else if (user_volt_options == "1")
            {
                // Assign 18 to voltage
                voltage = 18;
            }
            // Test input is "2"
            else if (user_volt_options == "2")
            {
                // Assign 24 to voltage
                voltage = 24;
            }
            // Otherwise
            else
            {
                // Write "Invalid option."
                Console.WriteLine("Invalid option.");
                // Return to calling (previous) method
                DisplayVacuums();
                return;
            }

            // Create found variable to hold list of found appliances.
            List<Appliance> found = new List<Appliance>();

            // Loop through Appliances
            foreach (Appliance appliance in Appliances)
            {
                // Check if current appliance is a vacuum
                if (Appliance.DetermineApplianceTypeFromItemNumber(appliance.ItemNumber) == Appliance.ApplianceTypes.Vacuum)
                {
                    // Downcast current Appliance to Vacuum object
                    Vacuum vacuum = (Vacuum)appliance;

                    // Test grade is "Any" or grade is equal to current vacuum grade and voltage is 0 or voltage is equal to current vacuum voltage
                    if (grade == "Any" || (grade == vacuum.Grade && (voltage == 0 || voltage == vacuum.BatteryVoltage)))
                    {
                        // Add current appliance in list to found list
                        found.Add(vacuum);
                    }
                }
            }

            // Display found appliances
            DisplayAppliancesFromList(found, 0);
        }

        /// <summary>
        /// Displays microwaves
        /// </summary>
      
        // DisplayMicrowaves() function
        // This function displays the available room type options and prompts the user to input a room type.
        // It then filters the list of appliances to find microwaves based on the selected room type.
        // Finally, it displays the found microwaves.

        public override void DisplayMicrowaves()
        {
            // Write "Possible options:"
            Console.WriteLine("Possible options:");

            // Write "0 - Any"
            Console.WriteLine("0 - Any");

            // Write "1 - Kitchen"
            Console.WriteLine("1 - Kitchen");

            // Write "2 - Work site"
            Console.WriteLine("2 - Work site");

            // Write "Enter room type:"
            Console.WriteLine("Enter room type:");

            // Get user input as string and assign to variable
            string input = Console.ReadLine();

            // Create character variable that holds room type
            char roomType;

            // Test input is "0"
            // Assign 'A' to room type variable
            if (input == "0")
                roomType = 'A';

            // Test input is "1"
            // Assign 'K' to room type variable
            else if (input == "1")
                roomType = 'K';

            // Test input is "2"
            // Assign 'W' to room type variable
            else if (input == "2")
                roomType = 'W';

            // Otherwise (input is something else)
            // Write "Invalid option."
            // Return to calling method
            // return;
            else
            {
                Console.WriteLine("Invail option");
                return;
            }

             // Create variable that holds list of 'found' appliances
             List<Appliance> foundApp = new List<Appliance>();

            // Loop through Appliances
            
            
            foreach (var appliance in Appliances)
            {
                // Test current appliance is Microwave
                if (appliance is Microwave microwave)
                {
                    // Down cast Appliance to Microwave
                    /*Appliance microwave = (Appliance)appliance;*/

                    // Test room type equals 'A' or microwave room type
                    if (roomType == 'A' || microwave.RoomType == roomType )
                    {
                        // Add current appliance in list to found list
                        foundApp.Add(microwave);
                    }

                }
            }

            // Display found appliances
            // DisplayAppliancesFromList(found, 0);
            DisplayAppliancesFromList(foundApp, 0);

        }

        /// <summary>
        /// Displays dishwashers
        /// </summary>
     
        // DisplayDishwashers() function
        // This function displays the possible options for sound ratings of dishwashers and prompts the user to input a sound rating.
        // It then filters the list of appliances to find dishwashers based on the selected sound rating.
        // Finally, it displays the found dishwashers.

        public override void DisplayDishwashers()
        {
            // Write "Possible options:"
            Console.WriteLine("Possible options:");

            // Write "0 - Any"
            Console.WriteLine("0 - Any");

            // Write "1 - Quietest"
            Console.WriteLine("1 - Quietest");

            // Write "2 - Quieter"
            Console.WriteLine("2 - Quiter");

            // Write "3 - Quiet"
            Console.WriteLine("3 - Quiet");

            // Write "4 - Moderate"
            Console.WriteLine("4 - Moderate");

            // Write "Enter sound rating:"
            Console.WriteLine("Enter sound rating:");

            // Get user input as string and assign to variable
            string input = Console.ReadLine() ;

            // Create variable that holds sound rating
            string soundRating;

            // Test input is "0"
            // Assign "Any" to sound rating variable
            if (input == "0")
                soundRating = "Any";

            // Test input is "1"
            // Assign "Qt" to sound rating variable
            else if (input == "1")
                soundRating = "Qt";

            // Test input is "2"
            // Assign "Qr" to sound rating variable
            else if (input == "2")
                soundRating = "Qr";

            // Test input is "3"
            // Assign "Qu" to sound rating variable
            else if (input == "3")
                soundRating = "Qu";

            // Test input is "4"
            // Assign "M" to sound rating variable
            else if (input == "4")
                soundRating = "M";

            // Otherwise (input is something else)
            // Write "Invalid option."
            // Return to calling method
            else
            {
                Console.WriteLine("Invalid option");
                return;
            }

            // Create variable that holds list of found appliances
            List<Appliance> foundApp = new List<Appliance>();


            // Loop through Appliances
            foreach (var appliance in Appliances) 
            {
                // Test if current appliance is dishwasher
                // Down cast current Appliance to Dishwasher
                if (appliance is Dishwasher dishwasher)

                    // Test sound rating is "Any" or equals soundrating for current dishwasher
                    if (soundRating == "Any"  || dishwasher.SoundRating == soundRating)
                        // Add current appliance in list to found list
                        foundApp.Add(appliance);
            }

            // Display found appliances (up to max. number inputted)
            // DisplayAppliancesFromList(found, 0);
            DisplayAppliancesFromList(foundApp, 0);
        }

        /// <summary>
        /// Generates random list of appliances
        /// </summary>
       
        // RandomList() function
        // It prompts the user to choose from a list of appliance types
        // (including any, refrigerators, vacuums, microwaves, and dishwashers)
        // and input the desired quantity.
        // The method then filters through the collection of appliances, selecting those that match the specified type.
        // Once the relevant appliances are identified,
        // it randomizes the list and displays the specified number of items to the user. 

        public override void RandomList()
        {
            int number_appliances = 0;
            // Write "Appliance Types"
            Console.WriteLine("Apppliance Types");

            // Write "0 - Any"
            // Write "1 – Refrigerators"
            // Write "2 – Vacuums"
            // Write "3 – Microwaves"
            // Write "4 – Dishwashers"
            Console.WriteLine("0 - Any\n" +
                "1 - Refrigerators\n" +
                "2 - Vacuums\n" +
                "3 - Microwaves\n" +
                "4 - Dishwashers\n");

            // Write "Enter type of appliance:"
            Console.WriteLine("Enter type of appliance:");

            // Get user input as string and assign to appliance type variable
            string? appliance_type_input = Console.ReadLine();

            // Write "Enter number of appliances: "
            Console.WriteLine("Enter number of appliances:");

            // Get user input as string and assign to variable
            string number_appliances_input = Console.ReadLine();

            // Convert user input from string to int
            if (number_appliances_input != null)
            {
                number_appliances = int.Parse(number_appliances_input);
            }
            else
            {
                RandomList();
            }
            // Create variable to hold list of found appliances

            List<Appliance> found = new List<Appliance>();

            // Loop through appliances
            foreach (Appliance appliance in Appliances)
            {
                // Test inputted appliance type is "0"
                // Add current appliance in list to found list
                if (appliance_type_input == "0")
                {
                    found.Add(appliance);
                }
                // Test inputted appliance type is "1"
                // Test current appliance type is Refrigerator
                // Add current appliance in list to found list
                else if (appliance_type_input == "1" && Appliance.DetermineApplianceTypeFromItemNumber(appliance.ItemNumber) == Appliance.ApplianceTypes.Refrigerator)
                {
                    found.Add(appliance);
                }
                // Test inputted appliance type is "2"
                // Test current appliance type is Vacuum
                // Add current appliance in list to found list
                else if (appliance_type_input == "2" && Appliance.DetermineApplianceTypeFromItemNumber(appliance.ItemNumber) == Appliance.ApplianceTypes.Vacuum)
                {
                    found.Add(appliance);
                }
                // Test inputted appliance type is "3"
                // Test current appliance type is Microwave
                // Add current appliance in list to found list
                else if (appliance_type_input == "3" && Appliance.DetermineApplianceTypeFromItemNumber(appliance.ItemNumber) == Appliance.ApplianceTypes.Microwave)
                {
                    found.Add(appliance);
                }
                // Test inputted appliance type is "4"
                // Test current appliance type is Dishwasher
                // Add current appliance in list to found list
                else if (appliance_type_input == "4" && Appliance.DetermineApplianceTypeFromItemNumber(appliance.ItemNumber) == Appliance.ApplianceTypes.Dishwasher)
                {
                    found.Add(appliance);
                }
            }

            // Randomize list of found appliances
            found.Sort(new RandomComparer());

            // Display found appliances (up to max. number inputted)
            DisplayAppliancesFromList(found, number_appliances);
        }
    }
}
